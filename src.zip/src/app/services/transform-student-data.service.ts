import { Injectable } from '@angular/core';
import { Student, } from '../interface/studentInterface';

@Injectable({
  providedIn: 'root'
})
export class TransformStudentDataService {

  transformStudentData(users: Student[]): Student[] {
    return users.map(user => ({
      id: user.id,
      name: user.name,
      percentage: user.percentage,
    }));
  }
}
