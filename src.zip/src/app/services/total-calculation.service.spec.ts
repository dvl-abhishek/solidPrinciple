import { TestBed } from '@angular/core/testing';

import { TotalStudentService } from './total-Student.service';

describe('TotalCalculationService', () => {
  let service: TotalStudentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TotalStudentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
